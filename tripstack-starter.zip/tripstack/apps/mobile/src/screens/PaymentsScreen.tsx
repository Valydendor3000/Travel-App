import React from 'react';
import { View, Text } from 'react-native';
export default function PaymentsScreen(){ return <View style={{padding:24}}><Text>Payments (placeholder)</Text></View>; }
