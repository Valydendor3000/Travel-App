export const onRequest: PagesFunction = async (context) => {
  // Placeholder function handler
  return new Response('OK from Pages Functions', { status: 200 })
}
