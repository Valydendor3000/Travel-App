import React from 'react';
import { View, Text } from 'react-native';
export default function ChatScreen(){ return <View style={{padding:24}}><Text>Chat (placeholder)</Text></View>; }
