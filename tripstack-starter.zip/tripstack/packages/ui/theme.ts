export const theme = {
  color: { primary: '#0ea5e9' }
}
