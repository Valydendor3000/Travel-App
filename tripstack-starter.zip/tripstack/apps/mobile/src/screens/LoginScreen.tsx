import React from 'react';
import { View, Text } from 'react-native';

export default function LoginScreen() {
  return <View style={{ padding: 24 }}><Text>Login (placeholder)</Text></View>;
}
